# SIG SATINFORMATIKA — Free v2

Paket pengganti dashboard awal: 30 URL per kiriman, pengambilan Apify melalui backend, analisis caption lokal transparan, grafik, periode hari/minggu/bulan/triwulan/semester/tahun, snapshot, JSON, CSV, dan cetak PDF.

## Status sebenarnya

Kode sudah dibuat dan diuji lokal. Belum dipasang ke repository atau website Anda. Token Apify belum tersedia; pengambilan live belum diuji. Tidak ada data demo. X saat ini didukung melalui impor JSON saja, bukan pengambilan otomatis. Facebook dibatasi kemampuan Actor untuk unggahan publik; profil pribadi tidak dijamin.

Analisis gratis adalah ringkasan berupa cuplikan caption, pencocokan kata topik, hashtag, dan indikasi sentimen berbasis kamus. Bukan analisis AI generatif, bukan verifikasi fakta, bukan analisis isi video/komentar. Tidak tersedia skor viralitas palsu. Persentase relevansi berarti kecocokan kata topik, bukan akurasi/kebenaran informasi.

## Langkah HP paling mudah: coba impor dahulu

1. Ekstrak ZIP di aplikasi File Saya.
2. Buka repository GitHub Anda di Chrome: https://github.com/dimasroyn/sig-satinformatika
3. Unggah `index.html` baru untuk mengganti file bernama sama. Jika tombol upload tidak terlihat, gunakan menu Chrome > Situs desktop. Simpan melalui Commit changes. Jangan menghapus repository.
4. Tunggu deployment Pages selesai. Muat ulang website.
5. Buat akun Free di https://console.apify.com/ tanpa mengaktifkan paket berbayar.
6. Buka salah satu Actor berikut di Apify. Jalankan 1 URL unggahan publik dulu menggunakan input URL, jumlah hasil 1, tanpa add-on unduhan atau transkripsi.
   - Instagram: https://apify.com/apify/instagram-scraper
   - TikTok: https://apify.com/clockworks/tiktok-scraper
   - Facebook: https://apify.com/apify/facebook-posts-scraper
7. Sesudah run berhasil, ekspor Dataset menjadi JSON.
8. Di dashboard, buka “Impor hasil Apify / cadangan”, pilih platform, lalu pilih file JSON tadi. Caption dan metrik yang tersedia masuk ke analisis dan grafik.

Cara ini memakai kredit gratis tetapi masih perlu menjalankan dan mengekspor dari Apify. Sekali tempel URL langsung di dashboard membutuhkan pemasangan backend berikut.

## Backend untuk 30 URL langsung

GitHub Pages hanya menampilkan HTML; server.mjs harus berjalan pada hosting Node.js terpisah. Pilih hosting dengan kuota gratis yang saat pendaftaran memang tersedia. Paket ini tidak otomatis membuat akun/hosting dan tidak menjanjikan kuota gratis tanpa batas.

1. Unggah server.mjs dan package.json ke repository. Jangan unggah token atau file .env.
2. Pada hosting Node.js, hubungkan repository, pilih Node.js 22+, start command `npm start`. Tidak perlu instal dependensi eksternal.
3. Pasang environment:
   - APIFY_TOKEN: token dari pengaturan akun Apify.
   - ACCESS_KEY: password backend acak minimal 24 karakter, berbeda dari token Apify.
   - ALLOWED_ORIGIN: https://dimasroyn.github.io (tanpa path atau garis miring akhir).
   - MAX_URLS_PER_HOUR: 30.
   - PORT: biasanya diatur hosting.
4. Buka alamat HTTPS backend yang diberikan hosting. Backend juga menyajikan dashboard.
5. Jika tetap memakai GitHub Pages, buka “Koneksi backend gratis” pada dashboard, isi alamat HTTPS backend dan ACCESS_KEY. Klik Periksa koneksi. Jangan masukkan APIFY_TOKEN ke formulir dashboard.
6. Mulai 1 URL dahulu, periksa biaya dan dataset di Apify. Setelah sukses coba beberapa URL, kemudian sampai 30 dalam satu kiriman.
7. Hasil diproses dua URL bersamaan; antrean lainnya berjalan bertahap. Jangan menutup halaman saat proses berlangsung.

## Perlindungan kredit

Pertahankan akun Apify Free. Kuota gratis saat dokumentasi disusun: kredit US$5/bulan. Ketika habis, layanan Free diblokir sampai periode berikutnya. Pembelian paket atau perubahan harga adalah keputusan terpisah. Tidak ada pembelian otomatis oleh kode ini.

Backend membatasi 30 start/jam per instance, dua proses bersamaan, timeout Actor 180 detik, maxTotalChargeUsd=0.05 per start. Ini batas per run, bukan janji harga, dan bukan batas bulanan akun. Beberapa tarif berbasis penggunaan dapat mengikuti aturan provider. Batas memori reset jika server restart. Pantau Console Apify, jangan bergantung pada penghitung lokal untuk tagihan. Pengambilan gagal dan pemrosesan ulang dapat memakai kredit. Tidak ada refresh otomatis agar hemat.

## Data dan laporan

Data di localStorage browser perangkat, bukan database bersama. Membuka di HP lain tidak menampilkan riwayat lama. Ekspor cadangan JSON dan impor untuk memindahkan data. Kode mengimpor data versi awal dari key sig-url-monitor-v1 pada browser/origin sama, tanpa menghapus key lama. Reset seluruh data menghapus kedua key setelah konfirmasi.

Filter tanggal menggunakan Asia/Jakarta. Minggu dimulai Senin. Dasar periode dapat dipilih antara tanggal pengambilan dan publikasi. Views dan interaksi merupakan snapshot terakhir unggahan yang lolos filter, bukan pertumbuhan historis periode. Snapshot tersimpan ketika URL yang sama diproses kembali. Selisih views terakhir ditampilkan jika ada dua snapshot. Riwayat sebelum pengumpulan tidak direkayasa. Perbandingan antarperiode, penjadwalan otomatis, database cloud, dan analisis AI generatif belum ditambahkan.

Grafik: distribusi platform, indikasi sentimen, tren jumlah unggahan per tanggal, dan peringkat views. Garis tren menghubungkan tanggal yang memiliki observasi; bukan pengukuran aktivitas lengkap seluruh platform. Tidak ada penyamaan views dengan jangkauan orang unik.

Cetak/PDF menggunakan hasil filter yang sedang aktif. Di Chrome pilih Cetak lalu Simpan sebagai PDF jika tersedia. CSV mengikuti filter; cadangan JSON berisi seluruh data. Data tidak tersedia ditampilkan “—”, angka nol tetap nol.

## Menjalankan lokal

Node.js 22 atau lebih baru:

    npm start

Buka http://localhost:8787. Tanpa environment, tampilan dan impor berfungsi; endpoint pengambilan menolak akses. Untuk pengujian:

    npm test

## Referensi

https://apify.com/pricing
https://docs.apify.com/api/v2/actor-runs-post
https://apify.com/apify/instagram-scraper/input-schema
https://apify.com/clockworks/tiktok-scraper/input-schema
https://apify.com/apify/facebook-posts-scraper/input-schema
